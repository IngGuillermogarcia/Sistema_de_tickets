<footer>
  <div class="container">
    <div class="row">
      <div class="col-sm-4">
        <h4 class="text-info">Siguenos</h4>
        <a href="#" class="text-warning"><i class="fa fa-facebook" aria-hidden="true"></i> &nbsp; Facebook</a><br>
        <a href="#" class="text-warning"><i class="fa fa-instagram" aria-hidden="true"></i> &nbsp; Instagram</a>
      </div>
      <div class="col-sm-4">
        <h4 class="text-info">Dirección</h4>
        <p class="text-warning">
        Ciudad: Ciudad<br>
        Telefono: +52 123456789<br>
        E-mail: su email<br>
        </p>
      </div>
      <div class="col-sm-4">
      </div>
    </div>
    <h4 class="text-center" style="color: #FFF;">Compusot CopyRight © <?php echo date("Y"); ?></h4>
  </div>
</footer>